/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hadiahprak9_2;

/**
 *
 * @author Asus
 */

import javax.swing.*;
import java.awt.event.*;

public abstract class HadiahPrak9_2 implements ActionListener {

    /**
     * @param args the command line arguments
     */
    private static void createAndShowGUI(){
        //make frame
        JFrame frame = new JFrame("Hadiah Praktek Pertemuan 9_2");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setBounds(20, 30, 300, 100);
        frame.getContentPane().setLayout(null);
        //make a button
        JButton button = new JButton("Click Me");
        frame.getContentPane().add(button);
        button.setBounds(20, 20, 200, 20);
        
        //intantiate an applicaton object
        HadiahPrak9_2 app = new HadiahPrak9_2(){};
        //make the label
        app.label = new JLabel("0 clicks");
        app.label.setBounds(20, 40, 200, 20);
        frame.getContentPane().add(app.label);
        
        button.addActionListener(app);
        frame.setVisible(true);
    }
    
    public void actionPerformed(ActionEvent e){
        
        //ini akan dieksekusi ketikan button diklik
        clickCount+=2;
        label.setText("Clicks = "+clickCount);
    }
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(new Runnable(){
            public void run(){
                createAndShowGUI();
            }
        });
    }
//application object fields
int clickCount=0;
JLabel label;
}
